#include "tower.h"
#include<QPainter>
#include<QDebug>

//class DT:public Tower
//{
//public:
//    DT();
//};

//class MT:public Tower
//{
//public:
//    MT();
//};

//Bullet Tower::setTarget(Soldier * s){
//    Bullet b(this->GetPos());
//    b.SetTarget(s);
//    return b;
//}

double Tower::leng(QPoint a, QPoint b){
    return sqrt(1.0*((a.x()-b.x())*(a.x()-b.x())+(a.y()-b.y())*(a.y()-b.y())));
}

bool Tower::isIn(QPoint p){
    qDebug()<<range<<leng(pos,p);
    return (range>=leng(pos,p));
}

void Tower::draw(QPainter * p){
        p->drawImage(this->pos.x()-67,this->pos.y()-121,this->t);
}

void Tower::SetPos(QPoint p){
    this->pos=p;
}

void Tower::mouseReleaseEvent(QMouseEvent *e){
    if(Qt::LeftButton == e->button()){
        LvUp();
    }
}

bool Tower::is_Cd(){
    if(cdCheck==0){
        qDebug()<<"yes!!";
        return true;
    }
    else
        cdCheck--;
    return false;
}

void Tower::LvUp(){
    this->dps+=5;
}

DT::DT(){
    this->t.load(":/image/image/things/DT.png");
    this->speed=2;
    this->cd=5;
    this->cdCheck=cd;
    this->ismagic=false;
    this->dps=20;
    this->range=150;
}
