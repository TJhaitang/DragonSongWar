#include "tower.h"
#include<QPainter>

//class DT:public Tower
//{
//public:
//    DT();
//};

//class MT:public Tower
//{
//public:
//    MT();
//};

Bullet Tower::setTarget(Soldier * s){
    Bullet b;
    b.SetTarget(s);
    return b;
}

double Tower::leng(QPoint a, QPoint b){
    return sqrt(1.0*((a.x()-b.x())*(a.x()-b.x())+(a.y()-b.y())*(a.y()-b.y())));
}

bool Tower::isIn(QPoint p){
    return (range>=leng(pos,p));
}

void Tower::draw(QPainter * p){
    p->drawImage(this->pos.x(),this->pos.y(),this->t);
}

void Tower::SetPos(QPoint p){
    this->pos=p;
}

void Tower::mouseReleaseEvent(QMouseEvent *e){
    if(Qt::LeftButton == e->button()){
        LvUp();
    }
}

void Tower::LvUp(){
    this->dps+=5;
}

DT::DT(){
    this->t.load(":/image/image/things/black.png");
    this->speed=2;
    this->cd=500;
    this->ismagic=false;
    this->dps=20;
    this->range=90;
}
