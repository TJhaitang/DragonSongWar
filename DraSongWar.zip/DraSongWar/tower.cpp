#include "tower.h"
#include<QPainter>
#include<QDebug>

//class DT:public Tower
//{
//public:
//    DT();
//};

//class MT:public Tower
//{
//public:
//    MT();
//};

//Bullet Tower::setTarget(Soldier * s){
//    Bullet b(this->GetPos());
//    b.SetTarget(s);
//    return b;
//}

Tower::Tower(QPoint p){
    this->SetPos(p);
    this->t.load(":/image/image/things/T.png");
}

double Tower::leng(QPoint a, QPoint b){
    return sqrt(1.0*((a.x()-b.x())*(a.x()-b.x())+(a.y()-b.y())*(a.y()-b.y())));
}

bool Tower::isIn(QPoint p){
    //qDebug()<<range<<leng(pos,p);
    return (range>=leng(pos,p));
}

void Tower::draw(QPainter * p){
        p->drawImage(this->pos.x()-67,this->pos.y()-121,this->t);
}

void Tower::SetPos(QPoint p){
    this->pos=p;
}

//void Tower::mousePressEvent(QMouseEvent *e){
//    if(Qt::LeftButton == e->button()){
//       qDebug()<<"hello";
//    }
//}

//void Tower::enterEvent(QEvent * e){
//    Q_UNUSED(e)
//    qDebug()<<"what??";
//}

//void Tower::mouseReleaseEvent(QMouseEvent *e){
//    if(Qt::LeftButton == e->button()){
//        qDebug()<<"thank you";
//        LvUp();
//    }
//}

bool Tower::is_Cd(){
    if(cdCheck==0){
//        qDebug()<<"yes!!";
        return true;
    }
    return false;
}

void Tower::LvUp(bool ismagic){
    if(this->lv==0)
    {
        this->ismagic=ismagic;
        if(this->ismagic==false)
            {this->t.load(":/image/image/things/DT.png");
            this->speed=2;
            this->cd=15;
            this->dps=10;
            }
        else
        {
            this->t.load(":/image/image/things/MT.png");
            this->speed=5;
            this->cd=30;
            this->dps=15;
        }
        this->cdCheck=cd;
        this->range=150;
        this->lv=1;
        repaint();
    }
    else//����������
    {
    this->dps+=5;
        this->lv+=1;
    }
}

void Tower::place(){
    this->t.load(":/image/image/things/T.png");
    this->lv=0;
    this->range=0;
}

//DT::DT(){    ʱ��������
//    this->t.load(":/image/image/things/DT.png");
//    this->speed=2;
//    this->cd=30;
//    this->cdCheck=cd;
//    this->ismagic=false;
//    this->dps=15;
//    this->range=150;
//}
