#ifndef GAME_H
#define GAME_H
#include <QWidget>
#include <QKeyEvent>
#include <QMouseEvent>
#include <QMediaPlayer>
#include <vector>
#include<QTimer>
#include"button.h"
#include"soldier.h"
#include"tower.h"

using namespace std;

extern int level;
extern bool cheat;
extern bool language;

class Gy:public QWidget{
public:
    Gy(QWidget *parent=0);
    ~Gy(){}
private:
    bool is_music=false;
    QImage fm;
    QMediaPlayer player;
    Button *bt2menu=new Button(this);
    Button *bt2bkstory=new Button(this);
    Button * bt2char=new Button(this);
    Button * bt2imp=new Button(this);
    Button *btlangch=new Button(this);
    Button *btcheach=new Button(this);
    QImage is_cheat;
    QImage langu;
    void draw();
    void back();
    void bkstory();
    void character();
    void important();
    void langChange();
    void cheatChange();
    void showlan();
    void showche();
    void enterEvent(QEvent *);
    void paintEvent(QPaintEvent *);
};


class Game:public QWidget {
public:
    Game(QWidget *parent = 0);
    ~Game(){}
    void start();
private:
    Button *ks=new Button(this);
    Button *tc=new Button(this);
    Button *gy=new Button(this);
    Button *bk=new Button(this);
    Button *lv[8]={new Button(this),new Button(this),new Button(this),new Button(this),
                  new Button(this),new Button(this),new Button(this),new Button(this)};
    QImage fm;
    QMediaPlayer player;
    bool is_music=false;
    void To_gy();
    void back();
    void draw();
    void IMload();
    void paintEvent(QPaintEvent *);
    void test();
    void blank(){}
    void togame1();
};

class chapter:public QWidget{
    Q_OBJECT
public:
    explicit chapter(QWidget *parent = 0);
protected:
    vector<QPoint *> p;
    QImage fm;
    QMediaPlayer player;
    vector<Soldier *> s;
    vector<Tower *> t;
    vector<Bullet *> b;
    QTimer *time;
    QTimer *singer;
    Button *bk=new Button(this);
    bool ingame;
    void draw();
    void search();
    void paintEvent(QPaintEvent *e);
protected slots:
    void paint();
    void bk2Lv();
    void sing();
};

class C1:public chapter{
public:
    C1();
protected:

};

#endif // GAME_H
