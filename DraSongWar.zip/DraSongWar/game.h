#ifndef GAME_H
#define GAME_H
#include <QWidget>
#include <QKeyEvent>
#include <QMouseEvent>
#include <QMediaPlayer>
#include"button.h"
#include"gaming.h"

extern int level;
extern bool cheat;
extern bool language;

class Gy:public QWidget{
public:
    Gy(QWidget *parent=0);
    ~Gy(){}
private:
    bool is_music=false;
    QImage fm;
    QMediaPlayer player;
    Button *bt2menu=new Button(this);
    Button *bt2bkstory=new Button(this);
    Button * bt2char=new Button(this);
    Button * bt2imp=new Button(this);
    Button *btlangch=new Button(this);
    Button *btcheach=new Button(this);
    QImage is_cheat;
    QImage langu;
    void draw();
    void back();
    void bkstory();
    void character();
    void important();
    void langChange();
    void cheatChange();
    void showlan();
    void showche();
    void enterEvent(QEvent *);
    void paintEvent(QPaintEvent *);
};


class Game:public QWidget {
public:
    Game(QWidget *parent = 0);
    ~Game(){}
private:
    Button *ks=new Button(this);
    Button *tc=new Button(this);
    Button *gy=new Button(this);
    Button *bk=new Button(this);
    Button *lv[8]={new Button(this),new Button(this),new Button(this),new Button(this),
                  new Button(this),new Button(this),new Button(this),new Button(this)};
    QImage fm;
    QMediaPlayer player;
    chapter c[8];
    void To_gy();
    void start();
    void back();
    void togame(int level);
    void draw();
    void IMload();
    void paintEvent(QPaintEvent *);
    void test();
    void blank(){}
};


#endif // GAME_H
