#ifndef BULLET_H
#define BULLET_H

#include"soldier.h"
#include <QWidget>

class Bullet{
public:
    Bullet(QPoint p);
    void SetTarget(Soldier *);
    void SetAtk(double atk);
    void draw(QPainter * p);
    void goahead();
    void atk();
    double leng(QPoint,QPoint);
    int L();
protected:
    double dps;
    double speed;//�˺�Խ�ߣ��ٶ�Խ������setatk�иı䣻
    bool ismagic;//ħ���ӵ��Ʒ�,�Ժ�����
    QImage blt;
    QPoint pos;
    Soldier * target;
};




#endif // BULLET_H
