#include"soldier.h"
#include<cmath>
#include<Qpainter>

Soldier::Soldier(){
    this->pos.setX(0);
    this->pos.setY(0);
}

void Soldier::GotAtk(double atk){
    atk-=atk*armor/100.0;
    this->blood-=atk;
    isdeath();
}

bool Soldier::isdeath(){
    if(this->blood<0.01)
        return 1;
    else
        return 0;
}

void Soldier::load(QString a){
    iden.load(a);
}

void Soldier::goahead(){
    this->pos+=QPoint(speed*cos(0.4),speed*sin(0.4));
}

void Soldier::draw(QPainter *p){
    p->drawImage(this->pos.x(),pos.y(),iden);
}

QPoint Soldier::Getpos(){
    return this->pos;
}

