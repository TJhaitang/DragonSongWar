#include"soldier.h"

Soldier::Soldier(int bld, int dps, int armor, int speed)
{
    this->armor=armor;
    this->blood=bld;
    this->dps=dps;
    this->speed=speed;
}

void Soldier::GotAtk(int atk){
    atk-=atk*armor/100;
    this->blood-=atk;
}

int Soldier::GetSped(){
    return this->speed;
}

int Soldier::Atk(){
    return this->dps;
}
