#include"soldier.h"
#include<cmath>
#include<Qpainter>


//class Road{
//public:
//    Road(){}
//    void setRoad(QPoint p[7]);
//    QPoint nextPos(double speed);
//    bool isOver();
//    double leng(QPoint,QPoint);
//protected:
//    QPoint * point;
//    QPoint NowPos;
//    int num=0;
//};

double Road::leng(QPoint a, QPoint b){
    return sqrt(1.0*((a.x()-b.x())*(a.x()-b.x())+(a.y()-b.y())*(a.y()-b.y())));
}

void Road::setRoad(QPoint *p){
    this->point=p;
}

double Road::L(){
    return leng(point[num],point[num+1]);
}

QPoint Road::nextPos(double speed){
    if(leng(NowPos,point[num+1])<=speed)
    {
        speed-=leng(NowPos,point[++num]);
        NowPos=point[num];
        if(num==sizeof(point)){
            this->isOver();
            return NowPos;
        }
    }
    this->NowPos+=QPoint(speed*(point[num+1].x()-point[num].x())/L(),speed*(point[num+1].y()-point[num].y()));
    return NowPos;
}

bool Road::isOver(){
    this->over=!this->over;
    return !this->over;
}

Soldier::Soldier(int who){
    this->pos.setX(0);
    this->pos.setY(0);
    this->who=who;
    if(who==0)//0,1,2,3/��ս��Զ�̡�t����
    {
        this->iden.load(":/image/image/things/Dra.png");
        this->dps=20;
        this->speed=3;
    }
}

void Soldier::SetRoad(QPoint *p){
    this->road.setRoad(p);
}

void Soldier::GotAtk(double atk){
    atk-=atk*armor/100.0;
    this->blood-=atk;
}

bool Soldier::isdeath(){
    if(this->blood<0.01)
        return 1;
    else
        return 0;
}

void Soldier::goahead(){
    this->pos=this->road.nextPos(speed);
}

void Soldier::draw(QPainter *p){
    p->drawImage(this->pos.x(),pos.y(),iden);
}

QPoint Soldier::Getpos(){
    return this->pos;
}

void Soldier::Atk(){}
void Soldier::Arm(){}
void Soldier::Heal(){}
