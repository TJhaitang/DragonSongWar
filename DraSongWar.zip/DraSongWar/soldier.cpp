#include"soldier.h"
#include<cmath>
#include<Qpainter>
#include<QDebug>

//class Road{
//public:
//    Road(){}
//    void setRoad(QPoint p[7]);
//    QPoint nextPos(double speed);
//    bool isOver();
//    double leng(QPoint,QPoint);
//protected:
//    QPoint * point;
//    QPoint NowPos;
//    int num=0;
//};

double Road::leng(QPoint a, QPoint b){
    return sqrt(1.0*((a.x()-b.x())*(a.x()-b.x())+(a.y()-b.y())*(a.y()-b.y())));
}

void Road::setRoad(vector<QPoint *> p){
    this->point=p;
    this->NowPos=*p[0];
//    int len=point.size();
//    qDebug()<<len<<"*";
//    for(int i=0;i<len;i++)
//        qDebug()<<point[i]->x()<<","<<point[i]->y()<<"|";
}

double Road::L(){
    return leng(NowPos,*point[num+1]);
}

QPoint Road::nextPos(double speed){
    if(leng(NowPos,*point[num+1])<speed)
    {
        speed-=leng(NowPos,*point[num+1]);
        NowPos=*point[num+1];
        num=num+1;
        if(num+1==point.size()){
            this->over=true;
            return NowPos;
        }
    }
    QPoint plus(speed*(point[num+1]->x()-NowPos.x())/L(),speed*(point[num+1]->y()-NowPos.y())/L());
    //qDebug()<<NowPos.x()<<NowPos.y();
    this->NowPos+=plus;
    return NowPos;
}

bool Road::isOver(){
    return this->over;
}

Soldier::Soldier(int who, int when, int Turn){
    this->pos.setX(0);
    this->pos.setY(0);
    this->who=who;
    this->WhenAper=when*40;
    this->turn=Turn;
    if(who==0)//0,1,2,3/��ս��Զ�̡�t����
    {
        this->iden.load(":/image/image/things/Dra.png");
        this->dps=20;
        this->speed=3;
    }
    if(who==1){

    }
    if(who==2){

    }
    if(who==3){

    }
}

void Soldier::SetRoad(vector<QPoint *> p){
    this->road.setRoad(p);
    this->pos=road.NowP();
}

void Soldier::GotAtk(double atk){
    atk-=atk*armor/100.0;
    this->blood-=atk;
}

bool Soldier::isdeath(){
    if(this->blood<0.01)
        return 1;
    else
        return 0;
}

bool Soldier::isover(){
    return road.isOver();
}

void Soldier::goahead(){
    this->pos=this->road.nextPos(speed);
//    qDebug()<<pos.x()<<","<<pos.y();
}

void Soldier::draw(QPainter *p){
    start=true;
    p->drawImage(this->pos.x()-19,pos.y()-28,iden);
    QRectF rec(this->pos+QPoint(-13,-50),this->pos+QPoint(30,30));
    p->drawText(rec,QString("%1").arg(this->blood));
}

QPoint Soldier::Getpos(){
    return this->pos;
}

int Soldier::Atk(){
    //��Ч���߹�����ʽ
    return this->dps;
}
void Soldier::Arm(){}
void Soldier::Heal(){}
