#include"game.h"
#include <QPainter>
#include <QTime>
#include <QDebug>
#include <QtCore/qmath.h>
#include <QMediaPlayer>

C1::C1(){
    this->fm.load(":/image/image/level/c1.png");
    player.setMedia(QUrl("qrc:/sound/sound/c1.mp3"));
    player.setVolume(sd);
    player.play();
//�ؿ�Ѫ��λ��
    this->r=new QRectF(QPoint(100,281),QPoint(200,350));
//��
    Tower *t1=new Tower(QPoint(486+67,362+121));
    Tower *t2=new Tower(QPoint(566+67,129+121));
    Tower *t3=new Tower(QPoint(733+67,344+121));
    Tower *t4=new Tower(QPoint(636+67,538+121));
    Tower *t5=new Tower(QPoint(326+67,529+121));
    Tower *t6=new Tower(QPoint(417+67,38+121));
    Tower *t7=new Tower(QPoint(236+67,300+121));
    this->t.push_back(t1);
    this->t.push_back(t2);
    this->t.push_back(t3);
    this->t.push_back(t4);
    this->t.push_back(t5);
    this->t.push_back(t6);
    this->t.push_back(t7);
//·��
    p.push_back(new QPoint(919,388));
    p.push_back(new QPoint(808,349));
    p.push_back(new QPoint(760,259));
    p.push_back(new QPoint(638,580));
    p.push_back(new QPoint(474,587));
    p.push_back(new QPoint(355,212));
    p.push_back(new QPoint(188,387));
//    qDebug()<<p.size()<<")";
//ʿ��

int bo=0;
for(int i=0;i<5;i++){
        Soldier *s1=new Soldier(0,1+3*i,bo);
        s1->SetRoad(p);
        this->s.push_back(s1);
}

bo=1;
for(int i=0;i<5;i++){
        Soldier *s1=new Soldier(0,1+3*i,bo);
        s1->SetRoad(p);
        this->s.push_back(s1);
}
for(int i=0;i<2;i++){
        Soldier *s2=new Soldier(2,3+2*i,bo);
        s2->SetRoad(p);
        this->s.push_back(s2);
}

bo=2;
for(int i=0;i<5;i++){
        Soldier *s1=new Soldier(0,1+3*i,bo);//1 4 7 10 13
        s1->SetRoad(p);
        this->s.push_back(s1);
}
for(int i=0;i<4;i++){
        Soldier *s1=new Soldier(0,2+3*i,bo);//2  5   8  11
        s1->SetRoad(p);
        this->s.push_back(s1);
}
for(int i=0;i<2;i++){
        Soldier *s2=new Soldier(2,4+2*i,bo);//4  6
        s2->SetRoad(p);
        this->s.push_back(s2);
}
        Soldier *s3=new Soldier(3,3,bo);
        s3->SetRoad(p);
        this->s.push_back(s3);

    for(int i=0;i<s.size();i++)
    {
        Bo[s[i]->GetTurn()]++;
    }
}

void C1::sing(){
    player.setMedia(QUrl("qrc:/sound/sound/c1.mp3"));
    this->player.setVolume(sd);
    this->player.play();
}

C2::C2(){
    this->fm.load(":/image/image/level/c2.png");
    player.setMedia(QUrl("qrc:/sound/sound/c2.mp3"));
    player.setVolume(sd);
    player.play();
//�ؿ�Ѫ��λ��
    this->r=new QRectF(QPoint(54,90),QPoint(200,350));
    //��
        Tower *t1=new Tower(QPoint(710+67,56+121));
        Tower *t2=new Tower(QPoint(706+67,230+121));
        Tower *t3=new Tower(QPoint(542+67,374+121));
        Tower *t4=new Tower(QPoint(242+67,546+121));
        Tower *t5=new Tower(QPoint(225+67,246+121));
        Tower *t6=new Tower(QPoint(386+67,68+121));
        Tower *t7=new Tower(QPoint(170+67,71+121));
        this->t.push_back(t1);
        this->t.push_back(t2);
        this->t.push_back(t3);
        this->t.push_back(t4);
        this->t.push_back(t5);
        this->t.push_back(t6);
        this->t.push_back(t7);
    //·��
        p.push_back(new QPoint(860,595));
        p.push_back(new QPoint(446,597));
        p.push_back(new QPoint(280,521));
        p.push_back(new QPoint(563,407));
        p.push_back(new QPoint(662,266));
        p.push_back(new QPoint(544,113));
        p.push_back(new QPoint(166,133));
        //ʿ��

        int bo=0;
        for(int i=0;i<5;i++){
                Soldier *s1=new Soldier(0,1+3*i,bo);
                s1->SetRoad(p);
                this->s.push_back(s1);
        }

        bo=1;
        for(int i=0;i<5;i++){
                Soldier *s1=new Soldier(0,1+3*i,bo);
                s1->SetRoad(p);
                this->s.push_back(s1);
        }
        for(int i=0;i<2;i++){
                Soldier *s2=new Soldier(2,3+2*i,bo);
                s2->SetRoad(p);
                this->s.push_back(s2);
        }

        bo=2;
        for(int i=0;i<5;i++){
                Soldier *s1=new Soldier(0,1+3*i,bo);//1 4 7 10 13
                s1->SetRoad(p);
                this->s.push_back(s1);
        }
        for(int i=0;i<4;i++){
                Soldier *s1=new Soldier(0,2+3*i,bo);//2  5   8  11
                s1->SetRoad(p);
                this->s.push_back(s1);
        }
        for(int i=0;i<2;i++){
                Soldier *s2=new Soldier(2,4+2*i,bo);//4  6
                s2->SetRoad(p);
                this->s.push_back(s2);
        }
                Soldier *s3=new Soldier(3,3,bo);
                s3->SetRoad(p);
                this->s.push_back(s3);

        bo=3;
        for(int i=0;i<10;i++){
                Soldier *s1=new Soldier(0,1+3*i,bo);//1 4 7 10 13
                s1->SetRoad(p);
                this->s.push_back(s1);
        }
        for(int i=0;i<8;i++){
                Soldier *s1=new Soldier(0,5+3*i,bo);//2  5   8  11
                s1->SetRoad(p);
                this->s.push_back(s1);
        }
        for(int i=0;i<4;i++){
                Soldier *s2=new Soldier(2,4+2*i,bo);//4  6
                s2->SetRoad(p);
                this->s.push_back(s2);
        }
        for(int i=0;i<4;i++){
                Soldier *s2=new Soldier(2,9+2*i,bo);//4  6
                s2->SetRoad(p);
                this->s.push_back(s2);
        }
        for(int i=0;i<5;i++)
        {
            Soldier *s3=new Soldier(3,4*i,bo);
            s3->SetRoad(p);
            this->s.push_back(s3);
        }

            for(int i=0;i<s.size();i++)
            {
                Bo[s[i]->GetTurn()]++;
            }
}

void C2::sing(){
    player.setMedia(QUrl("qrc:/sound/sound/c2.mp3"));
    this->player.setVolume(sd);
    this->player.play();
}
