#include"gaming.h"

Play::Play(chapter c){
    this->c=c;
}
