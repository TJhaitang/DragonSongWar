#ifndef SOLDIER_H
#define SOLDIER_H
#include<QWidget>
#include<vector>

using namespace std;

class Road{
public:
    Road(){}
    void setRoad(vector<QPoint *> );
    QPoint nextPos(double speed);
    QPoint NowP(){return NowPos;}
    bool isOver();
    double leng(QPoint,QPoint);
    double L();
protected:
    vector<QPoint *> point;
    QPoint NowPos;
    int num=0;
    bool over=false;
};

class Soldier{
protected:
    double blood=100;
    double dps=0;
    int armor=0;//����ֵ��1~100
    double speed=3;
    int here=0;//�����ɶ������
    int who;//����
    int WhenAper;//����ʱ��  ����ʱ����
    int turn;//���ֲ���
    bool start=false;
    Road road;
    QImage iden;
    QPoint pos;
public:
    Soldier(int who,int when,int Turn);
    int GetWhen(){return this->WhenAper;}
    int GetTurn(){return this->turn;}
    void SetRoad(vector<QPoint *> p);
    void draw(QPainter * p);
    void goahead();
    void GotAtk(double atk);
    int Atk();
    void Heal();
    void Arm();
    bool isdeath();
    bool isStart(){return this->start;}
    bool isover();
    QPoint Getpos();
};

//class Drg:public Soldier{     ���ټ̳У������������ֱ���
//public:
//    Drg();
//    void atk();
//};

//class Arm:public Drg{
//    Arm();
//};

//class Gun:public Soldier{
//public:
//    Gun();
//    void atk();
//};

//class Heal:public Gun{
//public:
//    Heal();
//    void heal();
//};



#endif // SOLDIER_H
