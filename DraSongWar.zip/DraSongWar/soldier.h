#ifndef SOLDIER_H
#define SOLDIER_H

struct Pos
{
    int x;
    int y;
};

class Soldier{
protected:
    int blood;
    int dps;
    int armor;//����ֵ��1~100
    int speed;
    Pos pos;
public:
    Soldier(int,int,int,int);
    void GotAtk(int atk);
    int GetSped();
    int Atk();
};



#endif // SOLDIER_H
