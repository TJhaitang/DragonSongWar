#ifndef SOLDIER_H
#define SOLDIER_H
#include<QWidget>

class Road{
public:
    Road(){}
    void setRoad(QPoint * p);
    QPoint nextPos(double speed);
    bool isOver();
    double leng(QPoint,QPoint);
    double L();
protected:
    QPoint * point;
    QPoint NowPos;
    int num=0;
    bool over=false;
};

class Soldier{
protected:
    double blood=100;
    double dps=0;
    int armor=0;//����ֵ��1~100
    double speed=3;
    int here=0;
    int who;//����
    Road road;
    QImage iden;
    QPoint pos;
public:
    Soldier(int who);
    void SetRoad(QPoint * p);
    void draw(QPainter * p);
    void goahead();
    void GotAtk(double atk);
    void Atk();
    void Heal();
    void Arm();
    bool isdeath();
    QPoint Getpos();
};

//class Drg:public Soldier{     ���ټ̳У������������ֱ���
//public:
//    Drg();
//    void atk();
//};

//class Arm:public Drg{
//    Arm();
//};

//class Gun:public Soldier{
//public:
//    Gun();
//    void atk();
//};

//class Heal:public Gun{
//public:
//    Heal();
//    void heal();
//};



#endif // SOLDIER_H
