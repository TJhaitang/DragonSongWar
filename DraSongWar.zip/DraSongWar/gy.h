#ifndef GY_H
#define GY_H

class Gy:public QWigets{

};

#endif // GY_H
