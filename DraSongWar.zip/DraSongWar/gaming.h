#ifndef GAMELEVEL_H
#define GAMELEVEL_H
#include <QWidget>
class chapter{

};

class Play:public QWidget{
public:
    Play(chapter c);
protected:
    chapter c;

};
#endif // GAMELEVEL_H
