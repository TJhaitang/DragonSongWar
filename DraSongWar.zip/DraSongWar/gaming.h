#ifndef GAMELEVEL_H
#define GAMELEVEL_H
#include <QWidget>
#include"soldier.h"
#include"tower.h"


#endif // GAMELEVEL_H
