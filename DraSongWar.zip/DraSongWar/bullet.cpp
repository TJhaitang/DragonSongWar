#include "bullet.h"
#include<QPainter>

//class Bullet{
//public:
//    Bullet();
//    Bullet(const Bullet & b);
//    void SetTarget(Soldier *);
//    void SetAtk(double atk);
//    void draw(QPainter * p);
//    void goahead();
//    double atk();
//protected:
//    double dps;
//    double speed;//�˺�Խ�ߣ��ٶ�Խ������setatk�иı䣻
//    bool ismagic;//ħ���ӵ��Ʒ�
//    QImage blt;
//    QPoint pos;
//    Soldier * target;
//};

Bullet::Bullet(){
    blt.load(":/image/image/things/black.png");
}

double Bullet::leng(QPoint a, QPoint b){
    return sqrt(1.0*((a.x()-b.x())*(a.x()-b.x())+(a.y()-b.y())*(a.y()-b.y())));
}

void Bullet::SetTarget(Soldier * t){
    this->target=t;
}

void Bullet::SetAtk(double atk){
    this->dps=atk;
}

void Bullet::draw(QPainter * p){
    p->drawImage(this->pos.x(),this->pos.y(),blt);
}

void Bullet::goahead(){
    this->pos+=QPoint(speed*(target->Getpos().x()-this->pos.x())/leng(target->Getpos(),this->pos),speed*(target->Getpos().y()-this->pos.y())/leng(target->Getpos(),this->pos));
}

double Bullet::atk(){
    return this->dps;
}
