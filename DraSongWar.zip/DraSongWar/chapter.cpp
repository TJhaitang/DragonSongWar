#include"game.h"
#include <QPainter>
#include <QTime>
#include <QDebug>
#include <QtCore/qmath.h>
#include <QMediaPlayer>

chapter::chapter(QWidget *parent):QWidget(parent){
    resize(1000,700);
    this->bk->set(":/image/image/gy/back_norm.jpg",":/image/image/gy/back_prs.jpg",":/image/image/gy/back_rls.jpg",860,20);
    bk->setFunc(this,my_selector(bk2Lv));
    singer=new QTimer(this);
    connect(singer,SIGNAL(timeout()),this,SLOT(sing()));
    singer->start(50);
    singer->setInterval(315000);
    time=new QTimer(this);
    connect(time,SIGNAL(timeout()),this,SLOT(paint()));
    time->start(50);
    time->setInterval(25);
}

void chapter::paintEvent(QPaintEvent *e){
    Q_UNUSED(e);
    search();
    this->TimeCheck();
    this->draw();

}

void chapter::draw(){
    QPainter *pa;
    QRectF rec(QPoint(51,67),QPoint(200,200));
    QRectF r(QPoint(100,281),QPoint(200,350));
    pa = new QPainter();
    pa->begin(this);
    pa->drawImage(0,0,fm);
    pa->drawText(rec,QString("%1/%2").arg(this->money).arg(2000+10000*cheat));
    pa->drawText(r,QString("blood %1").arg(this->blood));
    int Num=this->t.size();
    for(int i=0;i<Num;i++){
        t[i]->draw(pa);
    }
    if(s.size()==0)
    {
        level++;
        this->bk2Lv();
    }
    vector<Soldier *>::iterator it;
    it=s.begin();
    while (it!=s.end()) {
        if((*it)->GetWhen()<=when){

        (*it)->goahead();
        if((*it)->isdeath())
        {
            it=this->s.erase(it);
            this->money+=150;
//            Soldier *s1=new Soldier(0);//������
//            s1->SetRoad(p);//
//            this->s.push_back(s1);//

        }
        else if((*it)->isover())//���ܸ����˺�
        {
            it=this->s.erase(it);
            this->blood-=(*it)->Atk();
            if(this->blood<=0)
            {
                this->bk2Lv();
            }
        }
        (*it)->draw(pa);
        it++;
        }
        else
            break;
    }
    vector<Bullet *>::iterator bit;
    bit=b.begin();
    while (bit!=b.end()) {
        (*bit)->draw(pa);
        (*bit)->goahead();
        if((*bit)->L()<4)
        {
            (*bit)->atk();
            bit=this->b.erase(bit);
        }
        else
            bit++;
    }
    pa->end();
    delete pa;
}

void chapter::TimeCheck(){
    if(moneyCdCheck>0)
    {
        moneyCdCheck--;
    }
    if(moneyCdCheck==0)
    {
        this->money+=20;
        moneyCdCheck=moneyCD;
    }
    if(this->money>2000+10000*cheat){
        this->money=2000+10000*cheat;
    }
    if(bloodCdCheck>0)
    {
        bloodCdCheck--;
    }
    if(bloodCdCheck==0)
    {
        this->blood+=5;
        bloodCdCheck=bloodCD;
    }
    if(this->blood>100)
    {
        this->blood=100;
    }
}

void chapter::paint(){
//    nor.goahead();
    when++;
    this->repaint();
}

void chapter::bk2Lv(){
    this->player.stop();
    Game * tgame=new Game();
    tgame->show();
    tgame->start();
    this->close();
}

void chapter::sing(){
    this->player.setVolume(60);
    player.setMedia(QUrl("qrc:/sound/sound/c1.mp3"));
    this->player.play();
}

void chapter::search(){
    int sNum=s.size();
    int tNum=t.size();
    for(int i=0;i<tNum;i++)
    {
        for(int j=0;j<sNum;j++)
        {
            if(s[j]->isStart())
            if(t[i]->isIn(s[j]->Getpos())&&t[i]->is_Cd())
            {
//                qDebug()<<"yes";
                t[i]->CD();
                Bullet *nb=new Bullet(t[i]->GetCM(),t[i]->GetPos()+QPoint(44,-63)/*��������λ��*/);
                nb->SetTarget(s[j]);
                nb->SetAtk(t[i]->GetDps());
                b.push_back(nb);
            }
        }
        t[i]->CDdown();
    }
}

void chapter::mousePressEvent(QMouseEvent *event){
    Q_UNUSED(event);
}

void chapter::mouseReleaseEvent(QMouseEvent *event){
    int mx=event->x();
    int my=event->y();
    vector<Tower *>::iterator tow;
    tow=t.begin();
    while (tow!=t.end()) {
        QPoint p=(*tow)->GetPos();
        if(mx>p.x()-54&&mx<p.x()+60&&my<p.y()+31&&my>p.y()-24)
        {
            if(!(*tow)->GetT())
            {
            if(mx<p.x()-3)//����
            {
                if(this->money>=800)
                {
                (*tow)->LvUp(0);
                    this->money-=800;
                }
            }
            else if(mx>p.x()+4)//ħ��
            {
                if(this->money>=1200)
                {
                (*tow)->LvUp(1);
                this->money-=1200;
                }
            }
            }
            else
            {
                if(this->money>=900+100*(*tow)->GetCM())
                {
                    (*tow)->LvUp();
                    this->money-=900+100*(*tow)->GetCM();
                }
            }
        }
        tow++;
    }
}

C1::C1(){
    this->fm.load(":/image/image/level/c1.png");
    player.setMedia(QUrl("qrc:/sound/sound/c1.mp3"));
    player.setVolume(60);
    player.play();
//��
    Tower *t1=new Tower(QPoint(486+67,362+121));
    Tower *t2=new Tower(QPoint(566+67,129+121));
    Tower *t3=new Tower(QPoint(733+67,344+121));
    Tower *t4=new Tower(QPoint(636+67,538+121));
    Tower *t5=new Tower(QPoint(326+67,529+121));
    Tower *t6=new Tower(QPoint(417+67,38+121));
    Tower *t7=new Tower(QPoint(236+67,300+121));
    this->t.push_back(t1);
    this->t.push_back(t2);
    this->t.push_back(t3);
    this->t.push_back(t4);
    this->t.push_back(t5);
    this->t.push_back(t6);
    this->t.push_back(t7);
//·��
    p.push_back(new QPoint(919,388));
    p.push_back(new QPoint(808,349));
    p.push_back(new QPoint(760,259));
    p.push_back(new QPoint(638,580));
    p.push_back(new QPoint(474,587));
    p.push_back(new QPoint(355,212));
    p.push_back(new QPoint(188,387));
//    qDebug()<<p.size()<<")";
//ʿ��
    for(int j=0;j<20;j++){
    Soldier *s1=new Soldier(0,j*5,0);
    s1->SetRoad(p);
    this->s.push_back(s1);
    }
}




