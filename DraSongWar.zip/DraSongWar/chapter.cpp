#include"game.h"
#include <QPainter>
#include <QTime>
#include <QDebug>
#include <QtCore/qmath.h>
#include <QMediaPlayer>

chapter::chapter(QWidget *parent):QWidget(parent){
    this->setWindowTitle("DragonSong_War");
    this->load();
    resize(1000,700);
    time=new QTimer(this);
    connect(time,SIGNAL(timeout()),this,SLOT(paint()));
    time->start(50);
    time->setInterval(40);

}

void chapter::load(){
    fm.load(":/image/image/lszz.jpg");
//    nor.load(":/image/image/things/black.png");
}

void chapter::paintEvent(QPaintEvent *e){
    Q_UNUSED(e);
    this->draw();
}

void chapter::draw(){
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    pa->drawImage(0,0,fm);
//    nor.draw(pa);
    pa->end();
    delete pa;
}

void chapter::paint(){
//    nor.goahead();
    this->repaint();
}

