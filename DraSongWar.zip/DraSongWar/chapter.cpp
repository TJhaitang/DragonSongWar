#include"game.h"
#include <QPainter>
#include <QTime>
#include <QDebug>
#include <QtCore/qmath.h>
#include <QMediaPlayer>

chapter::chapter(QWidget *parent):QWidget(parent){
    resize(1000,700);
    this->bk->set(":/image/image/gy/back_norm.jpg",":/image/image/gy/back_prs.jpg",":/image/image/gy/back_rls.jpg",860,20);
    bk->setFunc(this,my_selector(bk2Lv));
    singer=new QTimer(this);
    connect(singer,SIGNAL(timeout()),this,SLOT(sing()));
    singer->start(50);
    singer->setInterval(315000);
    time=new QTimer(this);
    connect(time,SIGNAL(timeout()),this,SLOT(paint()));
    time->start(50);
    time->setInterval(30);
}

void chapter::paintEvent(QPaintEvent *e){
    Q_UNUSED(e);
    search();
    this->draw();
}

void chapter::draw(){
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    pa->drawImage(0,0,fm);
    int Num=this->t.size();
    for(int i=0;i<Num;i++){
        t[i]->draw(pa);
    }
    vector<Soldier *>::iterator it;
    it=s.begin();
    while (it!=s.end()) {
        (*it)->draw(pa);
        (*it)->goahead();
        if((*it)->isdeath())
        {
            it=this->s.erase(it);
            Soldier *s1=new Soldier(0);
            s1->SetRoad(p);
            this->s.push_back(s1);

        }
        else if((*it)->isover())
        {
            it=this->s.erase(it);
        }
        else
        it++;
    }
    vector<Bullet *>::iterator bit;
    bit=b.begin();
    while (bit!=b.end()) {
        (*bit)->draw(pa);
        (*bit)->goahead();
        if((*bit)->L()<4)
        {
            (*bit)->atk();
            bit=this->b.erase(bit);
        }
        else
            bit++;
    }
    pa->end();
    delete pa;
}

void chapter::paint(){
//    nor.goahead();
    this->repaint();
}

void chapter::bk2Lv(){
    this->player.stop();
    Game * tgame=new Game();
    tgame->show();
    tgame->start();
    this->close();
}

void chapter::sing(){
    this->player.setVolume(60);
    player.setMedia(QUrl("qrc:/sound/sound/c1.mp3"));
    this->player.play();
}

void chapter::search(){
    int sNum=s.size();
    int tNum=t.size();
    for(int i=0;i<tNum;i++)
    {
        for(int j=0;j<sNum;j++)
        {
            if(t[i]->isIn(s[i]->Getpos())&&t[i]->is_Cd())
            {
                qDebug()<<"yes";
                t[i]->CD();
                Bullet *nb=new Bullet(t[i]->GetPos());
                nb->SetTarget(s[i]);
                nb->SetAtk(t[i]->GetDps());
                b.push_back(nb);
            }
        }
    }
}



C1::C1(){
    this->fm.load(":/image/image/level/c1.png");
    player.setMedia(QUrl("qrc:/sound/sound/c1.mp3"));
    player.setVolume(60);
    player.play();

    Tower *t1=new DT;
    t1->SetPos(QPoint(486+67,362+121));
    this->t.push_back(t1);

    p.push_back(new QPoint(919,388));
    p.push_back(new QPoint(808,349));
    p.push_back(new QPoint(760,259));
    p.push_back(new QPoint(638,580));
    p.push_back(new QPoint(474,587));
    p.push_back(new QPoint(355,212));
    p.push_back(new QPoint(188,387));
//    qDebug()<<p.size()<<")";

    Soldier *s1=new Soldier(0);
    s1->SetRoad(p);
    this->s.push_back(s1);
}




