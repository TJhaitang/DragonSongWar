#include"game.h"
#include <QPainter>
#include <QTime>
#include <QDebug>
#include <QtCore/qmath.h>
#include <QMediaPlayer>

chapter::chapter(QWidget *parent):QWidget(parent){
    resize(1000,700);
    this->bk->set(":/image/image/gy/back_norm.jpg",":/image/image/gy/back_prs.jpg",":/image/image/gy/back_rls.jpg",16,23);
    bk->setFunc(this,my_selector(bk2Lv));
    singer=new QTimer(this);
    connect(singer,SIGNAL(timeout()),this,SLOT(sing()));
    singer->start(50);
    singer->setInterval(315000);
    time=new QTimer(this);
    connect(time,SIGNAL(timeout()),this,SLOT(paint()));
    time->start(50);
    time->setInterval(40);
}

void chapter::paintEvent(QPaintEvent *e){
    Q_UNUSED(e);
    search();
    this->draw();
}

void chapter::draw(){
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    pa->drawImage(0,0,fm);

    pa->end();
    delete pa;
}

void chapter::paint(){
//    nor.goahead();
    this->repaint();
}

void chapter::bk2Lv(){
    this->player.stop();
    Game * tgame=new Game();
    tgame->show();
    tgame->start();
    this->close();
}

void chapter::sing(){
    this->player.setVolume(60);
    player.setMedia(QUrl("qrc:/sound/sound/c1.mp3"));
    this->player.play();
}

void chapter::search(){

}



C1::C1(){
    this->fm.load(":/image/image/level/c1.png");
    player.setMedia(QUrl("qrc:/sound/sound/c1.mp3"));
    player.setVolume(60);
    player.play();
}




